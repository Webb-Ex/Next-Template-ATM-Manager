import React from 'react'

const page = () => {
  return (
    <div>ATM Schedules</div>
  )
}

export default page