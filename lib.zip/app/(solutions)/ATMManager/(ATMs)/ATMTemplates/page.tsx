import React from 'react'

const page = () => {
  return (
    <div>ATM Templates</div>
  )
}

export default page